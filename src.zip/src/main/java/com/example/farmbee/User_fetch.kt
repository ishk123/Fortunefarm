package com.example.farmbee

class User_fetch() {
    var uid = ""
    var category = ""
    var f_NAME = ""
    var l_NAME = ""
    var password = ""
    var phone_NO = ""
    var userid = ""
    constructor(uid:String,category:String,f_NAME:String,l_NAME:String,password:String,phone_NO:String,userid:String):this(){
        this.uid = uid
        this.category = category
        this.f_NAME = f_NAME
        this.l_NAME = l_NAME
        this.password = password
        this.phone_NO = phone_NO
        this.userid = userid
    }

}