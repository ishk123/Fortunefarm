package com.example.farmbee

class Pesticides_fetch() {
    var detail:String=""
    var price:Int=0
    var title:String=""

    constructor(detail:String,price:Int,title:String):this()
    {
        this.detail=detail
        this.price=price
        this.title=title
    }
}