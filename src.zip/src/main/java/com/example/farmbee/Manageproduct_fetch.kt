package com.example.farmbee

class Manageproduct_fetch()
{

    var detail:String=""
    var email:String = ""
    var price:Int=0
    var quantity:Int=0
    var spin:String=""
    var title:String=""
    constructor(detail:String,email:String,price:Int,quantity:Int,spin:String,title:String):this()
    {
        this.detail=detail
        this.email = email
        this.price=price
        this.quantity=quantity
        this.spin=spin
        this.title=title
    }


}